plugins {

    id("com.android.application")

    id("org.jetbrains.kotlin.android")

    id("org.jetbrains.kotlin.plugin.compose")

    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
}

android {

    namespace = "com.raktavahiniai"

    compileSdk = 34

    defaultConfig {

        applicationId = "com.raktavahiniai"

        minSdk = 24

        targetSdk = 34

        versionCode = 1

        versionName = "1.0"

        testInstrumentationRunner =
            "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {

        release {

            isMinifyEnabled = false

            proguardFiles(
                getDefaultProguardFile(
                    "proguard-android-optimize.txt"
                ),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {

        sourceCompatibility = JavaVersion.VERSION_17

        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {

        jvmTarget = "17"
    }

    buildFeatures {

        compose = true
    }


}

dependencies {

    implementation("androidx.core:core-ktx:1.13.1")

    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.0")

    implementation("androidx.activity:activity-compose:1.9.0")

    implementation(
        platform(
            "androidx.compose:compose-bom:2024.05.00"
        )
    )

    implementation("androidx.compose.ui:ui")

    implementation("androidx.compose.ui:ui-graphics")

    implementation("androidx.compose.ui:ui-tooling-preview")

    implementation("androidx.compose.material3:material3")

    implementation(
        "androidx.navigation:navigation-compose:2.7.7"
    )

    implementation(
        "androidx.compose.material:material-icons-extended"
    )

    // ROOM DATABASE

    implementation("androidx.room:room-runtime:2.6.1")

    implementation("androidx.room:room-ktx:2.6.1")

    ksp("androidx.room:room-compiler:2.6.1")

    // DEBUG

    debugImplementation(
        "androidx.compose.ui:ui-tooling"
    )

    debugImplementation(
        "androidx.compose.ui:ui-test-manifest"
    )

    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))

    implementation("com.google.firebase:firebase-auth-ktx")

    implementation(
        "com.google.firebase:firebase-firestore-ktx:25.1.0"
    )

    implementation("org.osmdroid:osmdroid-android:6.1.18")

    implementation("org.osmdroid:osmdroid-android:6.1.18")

    implementation(
        "io.coil-kt:coil-compose:2.6.0"
    )

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}