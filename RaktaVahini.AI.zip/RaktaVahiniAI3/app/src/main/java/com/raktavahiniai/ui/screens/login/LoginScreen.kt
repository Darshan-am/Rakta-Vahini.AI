package com.raktavahiniai.ui.screens.login

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.raktavahiniai.navigation.NavRoutes

@Composable
fun LoginScreen(navController: NavController) {

    val context = LocalContext.current

    val auth = FirebaseAuth.getInstance()

    var email by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState())
    ) {

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "🩸 Rakta-Vahini",
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Login to continue",
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(32.dp))

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Email")
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
            },
            modifier = Modifier.fillMaxWidth(),
            label = {
                Text("Password")
            },
            visualTransformation =
                PasswordVisualTransformation()
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {

                if (
                    email.isBlank() ||
                    password.isBlank()
                ) {

                    Toast.makeText(
                        context,
                        "Please fill all fields",
                        Toast.LENGTH_SHORT
                    ).show()

                    return@Button
                }

                auth.signInWithEmailAndPassword(
                    email,
                    password
                ).addOnCompleteListener { task ->

                    if (task.isSuccessful) {

                        Toast.makeText(
                            context,
                            "Login Successful",
                            Toast.LENGTH_SHORT
                        ).show()

                        navController.navigate(
                            NavRoutes.HOME
                        ) {

                            popUpTo(
                                NavRoutes.LOGIN
                            ) {
                                inclusive = true
                            }
                        }

                    } else {

                        Toast.makeText(
                            context,
                            task.exception?.message
                                ?: "Login Failed",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp)
        ) {

            Text("Login")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(
            onClick = {

                navController.navigate(
                    NavRoutes.REGISTER
                )
            }
        ) {

            Text(
                text =
                    "Don't have an account? Register"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
            onClick = {

                if (email.isBlank()) {

                    Toast.makeText(
                        context,
                        "Enter your email first",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {

                    auth.sendPasswordResetEmail(
                        email
                    ).addOnCompleteListener { task ->

                        if (task.isSuccessful) {

                            Toast.makeText(
                                context,
                                "Password reset email sent",
                                Toast.LENGTH_LONG
                            ).show()

                        } else {

                            Toast.makeText(
                                context,
                                task.exception?.message
                                    ?: "Failed to send email",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
        ) {

            Text("Forgot Password?")
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}