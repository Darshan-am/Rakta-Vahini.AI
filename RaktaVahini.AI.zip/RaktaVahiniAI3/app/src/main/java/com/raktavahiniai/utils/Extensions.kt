package com.raktavahiniai.utils

class Extensions {
}