package com.raktavahiniai.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.raktavahiniai.data.local.entities.UserEntity

@Dao
interface UserDao {

    @Insert
    suspend fun insertUser(
        user: UserEntity
    )

    @Query("SELECT * FROM users")
    suspend fun getAllUsers():
            List<UserEntity>

    @Query(
        "UPDATE users SET available = :available WHERE id = :userId"
    )
    suspend fun updateAvailability(
        userId: Int,
        available: Boolean
    )
}