package com.raktavahiniai.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BottomNav(
    val route: String,
    val title: String,
    val icon: ImageVector
) {

    object Home : BottomNav(
        route = "home",
        title = "Home",
        icon = Icons.Default.Home
    )

    object History : BottomNav(
        route = "history",
        title = "History",
        icon = Icons.Default.History
    )

    object Profile : BottomNav(
        route = "profile",
        title = "Profile",
        icon = Icons.Default.Person
    )

    object Settings : BottomNav(
        route = "settings",
        title = "Settings",
        icon = Icons.Default.Settings
    )
}