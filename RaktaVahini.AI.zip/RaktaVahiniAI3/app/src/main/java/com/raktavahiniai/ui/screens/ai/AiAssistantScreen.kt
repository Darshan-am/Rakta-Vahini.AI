package com.raktavahiniai.ui.screens.ai

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.utils.LanguageManager
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import com.raktavahiniai.network.GeminiApi

@Composable
fun AiAssistantScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    var userQuestion by remember {
        mutableStateOf("")
    }

    var aiResponse by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🧠 ಎಐ ರಕ್ತ ಸಹಾಯಕ"

                    "Hindi" ->
                        "🧠 एआई ब्लड असिस्टेंट"

                    else ->
                        "🧠 AI Blood Assistant"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = userQuestion,

            onValueChange = {
                userQuestion = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ನಿಮ್ಮ ಪ್ರಶ್ನೆಯನ್ನು ಕೇಳಿ"

                        "Hindi" ->
                            "अपना प्रश्न पूछें"

                        else ->
                            "Ask your question"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                GeminiApi.askQuestion(
                    userQuestion
                ) { response ->

                    aiResponse = response
                }
            },

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ಎಐ ಕೇಳಿ"

                    "Hindi" ->
                        "एआई से पूछें"

                    else ->
                        "Ask AI"
                }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (aiResponse.isNotBlank()) {

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text =

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ಎಐ ಉತ್ತರ"

                                "Hindi" ->
                                    "एआई उत्तर"

                                else ->
                                    "AI Response"
                            },

                        style =
                            MaterialTheme
                                .typography
                                .headlineSmall
                    )

                    Spacer(
                        modifier =
                            Modifier.height(12.dp)
                    )

                    Text(text = aiResponse)
                }
            }
        }
    }
}

fun getAiResponse(
    question: String,
    language: String
): String {

    return when {

        question.contains(
            "O+",
            ignoreCase = true
        ) -> {

            when (language) {

                "Kannada" ->
                    "O+ ರಕ್ತವು O+, A+, B+, ಮತ್ತು AB+ ಗೆ ದಾನ ಮಾಡಬಹುದು."

                "Hindi" ->
                    "O+ रक्त O+, A+, B+, और AB+ को दान किया जा सकता है।"

                else ->
                    "O+ blood can donate to O+, A+, B+, and AB+."
            }
        }

        question.contains(
            "emergency",
            ignoreCase = true
        ) -> {

            when (language) {

                "Kannada" ->
                    "ತುರ್ತು ಸಂದರ್ಭಗಳಲ್ಲಿ ತಕ್ಷಣ ರಕ್ತದಾನಿಗಳನ್ನು ಸಂಪರ್ಕಿಸಿ."

                "Hindi" ->
                    "आपातकाल में तुरंत रक्तदाताओं से संपर्क करें।"

                else ->
                    "In emergencies, contact nearby donors immediately."
            }
        }

        else -> {

            when (language) {

                "Kannada" ->
                    "ವಿವರವಾದ ವೈದ್ಯಕೀಯ ಸಲಹೆಗಾಗಿ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ."

                "Hindi" ->
                    "विस्तृत चिकित्सा सलाह के लिए डॉक्टर से संपर्क करें।"

                else ->
                    "Please consult a healthcare professional for detailed medical advice."
            }
        }
    }
}