package com.raktavahiniai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raktavahiniai.navigation.AppNavigation
import com.raktavahiniai.ui.theme.RaktaVahiniAITheme
import com.raktavahiniai.ui.theme.ThemeViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContent {

            val themeViewModel:
                    ThemeViewModel =
                viewModel()

            RaktaVahiniAITheme(
                darkTheme =
                    themeViewModel
                        .isDarkMode
                        .value
            ) {

                AppNavigation(
                    themeViewModel
                )
            }
        }
    }
}