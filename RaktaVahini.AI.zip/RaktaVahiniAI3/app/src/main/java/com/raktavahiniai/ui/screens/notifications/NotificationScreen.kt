package com.raktavahiniai.ui.screens.notifications

class NotificationScreen {
}