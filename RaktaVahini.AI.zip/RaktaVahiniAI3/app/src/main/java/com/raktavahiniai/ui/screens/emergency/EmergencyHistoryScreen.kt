package com.raktavahiniai.ui.screens.emergencyhistory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raktavahiniai.utils.LanguageManager

data class EmergencyHistoryItem(

    val patientName: String,

    val bloodGroup: String,

    val status: String
)

@Composable
fun EmergencyHistoryScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val historyList = listOf(

        EmergencyHistoryItem(
            "Ramesh",
            "O+",
            "Completed"
        ),

        EmergencyHistoryItem(
            "Priya",
            "A+",
            "Pending"
        ),

        EmergencyHistoryItem(
            "Karthik",
            "B+",
            "Completed"
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "📜 ತುರ್ತು ಇತಿಹಾಸ"

                    "Hindi" ->
                        "📜 आपातकालीन इतिहास"

                    else ->
                        "📜 Emergency History"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn {

            items(historyList) { item ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {

                    Column(
                        modifier = Modifier
                            .padding(20.dp)
                    ) {

                        Text(
                            text = item.patientName,

                            fontWeight =
                                FontWeight.Bold,

                            fontSize = 20.sp
                        )

                        Spacer(
                            modifier =
                                Modifier.height(8.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ರಕ್ತ ಗುಂಪು: ${
                                        item.bloodGroup
                                    }"

                                "Hindi" ->

                                    "ब्लड ग्रुप: ${
                                        item.bloodGroup
                                    }"

                                else ->

                                    "Blood Group: ${
                                        item.bloodGroup
                                    }"
                            }
                        )

                        Spacer(
                            modifier =
                                Modifier.height(4.dp)
                        )

                        Text(

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->

                                    "ಸ್ಥಿತಿ: ${
                                        if (
                                            item.status ==
                                            "Completed"
                                        )
                                            "ಪೂರ್ಣಗೊಂಡಿದೆ"
                                        else
                                            "ಬಾಕಿ"
                                    }"

                                "Hindi" ->

                                    "स्थिति: ${
                                        if (
                                            item.status ==
                                            "Completed"
                                        )
                                            "पूर्ण"
                                        else
                                            "लंबित"
                                    }"

                                else ->

                                    "Status: ${
                                        item.status
                                    }"
                            }
                        )
                    }
                }
            }
        }
    }
}