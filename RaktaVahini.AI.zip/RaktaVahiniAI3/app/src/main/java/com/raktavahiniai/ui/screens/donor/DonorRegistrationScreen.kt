package com.raktavahiniai.ui.screens.donor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.utils.LanguageManager
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.google.firebase.firestore.FirebaseFirestore
import com.raktavahiniai.model.DonorModel

@Composable
fun DonorRegistrationScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    val context = LocalContext.current

    val firestore =
        FirebaseFirestore
            .getInstance()

    var donorName by remember {
        mutableStateOf("")
    }

    var bloodGroup by remember {
        mutableStateOf("")
    }

    var location by remember {
        mutableStateOf("")
    }

    var phoneNumber by remember {
        mutableStateOf("")
    }

    var successMessage by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🩸 ದಾನಿ ನೋಂದಣಿ"

                    "Hindi" ->
                        "🩸 दाता पंजीकरण"

                    else ->
                        "🩸 Donor Registration"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = donorName,

            onValueChange = {
                donorName = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ದಾನಿಯ ಹೆಸರು"

                        "Hindi" ->
                            "दाता का नाम"

                        else ->
                            "Donor Name"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = bloodGroup,

            onValueChange = {
                bloodGroup = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ರಕ್ತ ಗುಂಪು"

                        "Hindi" ->
                            "ब्लड ग्रुप"

                        else ->
                            "Blood Group"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = location,

            onValueChange = {
                location = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಸ್ಥಳ"

                        "Hindi" ->
                            "स्थान"

                        else ->
                            "Location"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = phoneNumber,

            onValueChange = {
                phoneNumber = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಫೋನ್ ಸಂಖ್ಯೆ"

                        "Hindi" ->
                            "फ़ोन नंबर"

                        else ->
                            "Phone Number"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                val donor = DonorModel(

                    donorName =
                        donorName,

                    bloodGroup =
                        bloodGroup,

                    location =
                        location,

                    phoneNumber =
                        phoneNumber
                )

                firestore
                    .collection("donors")
                    .add(donor)

                    .addOnSuccessListener {

                        successMessage =

                            when (
                                selectedLanguage.value
                            ) {

                                "Kannada" ->
                                    "ದಾನಿ ಯಶಸ್ವಿಯಾಗಿ ನೋಂದಾಯಿಸಲಾಗಿದೆ."

                                "Hindi" ->
                                    "दाता सफलतापूर्वक पंजीकृत हुआ।"

                                else ->
                                    "Donor Registered Successfully."
                            }

                        donorName = ""
                        bloodGroup = ""
                        location = ""
                        phoneNumber = ""
                    }

                    .addOnFailureListener {

                        Toast
                            .makeText(
                                context,
                                "Failed",
                                Toast.LENGTH_SHORT
                            )
                            .show()
                    }
            },

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ನೋಂದಣಿ ಮಾಡಿ"

                    "Hindi" ->
                        "पंजीकरण करें"

                    else ->
                        "Register"
                }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (successMessage.isNotEmpty()) {

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = successMessage,

                    modifier =
                        Modifier.padding(20.dp)
                )
            }
        }
    }
}