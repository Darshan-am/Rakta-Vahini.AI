package com.raktavahiniai.ui.screens.profile

class ProfileViewModel {
}