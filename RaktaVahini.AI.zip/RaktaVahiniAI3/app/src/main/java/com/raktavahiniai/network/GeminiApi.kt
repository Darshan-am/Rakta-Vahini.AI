package com.raktavahiniai.network

import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response

import org.json.JSONArray
import org.json.JSONObject

import java.io.IOException

object GeminiApi {

    private const val API_KEY =
        "AIzaSyABVTIsRt7jIGfYvl360CJsbmfLdSs9h0Q"

    fun askQuestion(
        question: String,
        callback: (String) -> Unit
    ) {

        val client =
            OkHttpClient()

        val json =
            JSONObject()

        val contents =
            JSONArray()

        val content =
            JSONObject()

        val parts =
            JSONArray()

        val textPart =
            JSONObject()

        textPart.put(
            "text",
            question
        )

        parts.put(textPart)

        content.put(
            "parts",
            parts
        )

        contents.put(content)

        json.put(
            "contents",
            contents
        )

        val body = json
            .toString()

            .toRequestBody(
                "application/json"
                    .toMediaType()
            )

        val request =
            Request.Builder()

                .url(
                    "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=$API_KEY"
                )

                .post(body)

                .build()

        client.newCall(request)

            .enqueue(object : Callback {

                override fun onFailure(
                    call: Call,
                    e: IOException
                ) {

                    callback(
                        "Failed: ${e.message}"
                    )
                }

                override fun onResponse(
                    call: Call,
                    response: Response
                ) {

                    try {

                        val responseBody =
                            response.body?.string()

                        if (
                            responseBody.isNullOrEmpty()
                        ) {

                            callback(
                                "Empty response from AI"
                            )

                            return
                        }

                        val jsonObject =
                            JSONObject(responseBody)

                        if (
                            jsonObject.has("candidates")
                        ) {

                            val text =

                                jsonObject

                                    .getJSONArray(
                                        "candidates"
                                    )

                                    .getJSONObject(0)

                                    .getJSONObject(
                                        "content"
                                    )

                                    .getJSONArray(
                                        "parts"
                                    )

                                    .getJSONObject(0)

                                    .getString(
                                        "text"
                                    )

                            callback(text)

                        } else if (

                            jsonObject.has("error")

                        ) {

                            val errorMessage =

                                jsonObject

                                    .getJSONObject(
                                        "error"
                                    )

                                    .getString(
                                        "message"
                                    )

                            callback(
                                "AI Error: $errorMessage"
                            )

                        } else {

                            callback(
                                "Unknown AI response"
                            )
                        }

                    } catch (e: Exception) {

                        callback(
                            "AI Error: ${e.message}"
                        )
                    }
                }

                          })
    }
}