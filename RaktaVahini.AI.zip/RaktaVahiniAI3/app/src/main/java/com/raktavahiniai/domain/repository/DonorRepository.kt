package com.raktavahiniai.domain.repository

class DonorRepository {
}