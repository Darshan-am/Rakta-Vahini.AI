package com.raktavahiniai.ui.screens.onboarding

class OnboardingScreen {
}