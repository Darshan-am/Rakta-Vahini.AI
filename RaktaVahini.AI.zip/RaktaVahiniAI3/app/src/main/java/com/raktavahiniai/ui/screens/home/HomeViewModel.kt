package com.raktavahiniai.ui.screens.home

class HomeViewModel {
}