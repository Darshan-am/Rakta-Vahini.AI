package com.raktavahiniai.di

import android.content.Context
import androidx.room.Room
import com.raktavahiniai.data.local.database.AppDatabase

object DatabaseModule {

    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {

        return INSTANCE ?: synchronized(this) {

            val instance = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "rakta_vahini_db"
            ).build()

            INSTANCE = instance

            instance
        }
    }
}