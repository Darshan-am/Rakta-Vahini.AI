package com.raktavahiniai.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.utils.LanguageManager

@Composable
fun SettingsScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "⚙ ಸೆಟ್ಟಿಂಗ್ಸ್"

                    "Hindi" ->
                        "⚙ सेटिंग्स"

                    else ->
                        "⚙ Settings"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಆಪ್ ಆವೃತ್ತಿ"

                        "Hindi" ->
                            "ऐप संस्करण"

                        else ->
                            "App Version"
                    }
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                Text("1.0.0")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಡೆವಲಪರ್"

                        "Hindi" ->
                            "डेवलपर"

                        else ->
                            "Developer"
                    }
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                Text("Darshan AM")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಆಪ್ ಬಗ್ಗೆ"

                        "Hindi" ->
                            "ऐप के बारे में"

                        else ->
                            "About App"
                    }
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "Rakta-Vahini AI ತುರ್ತು ಸಂದರ್ಭಗಳಲ್ಲಿ ರಕ್ತದಾನಿಗಳನ್ನು ಶೀಘ್ರವಾಗಿ ಹುಡುಕಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ."

                        "Hindi" ->
                            "Rakta-Vahini AI आपातकालीन स्थितियों में रक्तदाताओं को जल्दी खोजने में मदद करता है।"

                        else ->
                            "Rakta-Vahini AI helps users quickly find blood donors during emergencies."
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ಸಹಾಯ"

                        "Hindi" ->
                            "आपातकालीन सहायता"

                        else ->
                            "Emergency Support"
                    }
                )

                Spacer(
                    modifier =
                        Modifier.height(8.dp)
                )

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ಸಂದರ್ಭಗಳಲ್ಲಿ ಸಮೀಪದ ಆಸ್ಪತ್ರೆಗಳನ್ನು ಸಂಪರ್ಕಿಸಿ."

                        "Hindi" ->
                            "आपातकालीन स्थिति में नजदीकी अस्पताल से संपर्क करें।"

                        else ->
                            "Contact nearby hospitals or emergency services immediately during critical situations."
                    }
                )
            }
        }
    }
}