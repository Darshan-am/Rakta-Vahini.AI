package com.raktavahiniai.ui.screens.notifications

class NotificationViewModel {
}