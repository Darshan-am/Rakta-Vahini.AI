package com.raktavahiniai.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.raktavahiniai.navigation.NavRoutes
import com.raktavahiniai.utils.LanguageManager
import com.raktavahiniai.utils.DateTimeUtils
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun HomeScreen(navController: NavController) {

    var expanded by remember {
        mutableStateOf(false)
    }

    val selectedLanguage =
        LanguageManager.selectedLanguage

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = false,
                    onClick = {
                        navController.navigate(
                            NavRoutes.HOME
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text("Home")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {
                        navController.navigate(
                            NavRoutes.HISTORY
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "History"
                        )
                    },
                    label = {
                        Text("History")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {
                        navController.navigate(
                            NavRoutes.PROFILE
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = {
                        Text("Profile")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {
                        navController.navigate(
                            NavRoutes.SETTINGS
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings"
                        )
                    },
                    label = {
                        Text("Settings")
                    }
                )
            }
        }

    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
                .verticalScroll(
                    rememberScrollState()
                )
        ) {

            Text(
                text = "🩸 Rakta-Vahini",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text =
                    "Date: ${
                        DateTimeUtils
                            .getCurrentDate()
                    }"
            )

            Text(
                text =
                    "Time: ${
                        DateTimeUtils
                            .getCurrentTime()
                    }"
            )

            Spacer(modifier = Modifier.height(24.dp))
            Box {

                Button(
                    onClick = {
                        expanded = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {

                    Text(
                        "Language: ${selectedLanguage.value}"
                    )
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = {
                        expanded = false
                    }
                ) {

                    DropdownMenuItem(
                        text = {
                            Text("English")
                        },
                        onClick = {

                            selectedLanguage.value =
                                "English"

                            expanded = false
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text("Kannada")
                        },
                        onClick = {

                            selectedLanguage.value =
                                "Kannada"

                            expanded = false
                        }
                    )

                    DropdownMenuItem(
                        text = {
                            Text("Hindi")
                        },
                        onClick = {

                            selectedLanguage.value =
                                "Hindi"

                            expanded = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.DONOR
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ರಕ್ತದಾನಿಗಳನ್ನು ಹುಡುಕಿ"

                        "Hindi" ->
                            "रक्त दाताओं को खोजें"

                        else ->
                            "Search Donors"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.EMERGENCY
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ವಿನಂತಿ"

                        "Hindi" ->
                            "आपातकालीन अनुरोध"

                        else ->
                            "Emergency Request"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.EMERGENCY_HISTORY
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ಇತಿಹಾಸ"

                        "Hindi" ->
                            "आपातकालीन इतिहास"

                        else ->
                            "Emergency History"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.HISTORY
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ದಾನದ ಇತಿಹಾಸ"

                        "Hindi" ->
                            "दान इतिहास"

                        else ->
                            "Donation History"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.SOS
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ಸಹಾಯ"

                        "Hindi" ->
                            "आपातकालीन सहायता"

                        else ->
                            "Emergency SOS"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    navController.navigate(
                        NavRoutes.EMERGENCY_FEED
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ಮಾಹಿತಿ"

                        "Hindi" ->
                            "लाइव आपातकालीन फ़ीड"

                        else ->
                            "Live Emergency Feed"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {

                    navController.navigate(
                        NavRoutes.RANKING
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಅತ್ಯುತ್ತಮ ದಾನಿಗಳು"

                        "Hindi" ->
                            "शीर्ष दाता"

                        else ->
                            "Top Donors"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))


            Button(
                onClick = {

                    navController.navigate(
                        NavRoutes.DONOR_MAP
                    )
                },

                modifier = Modifier
                    .fillMaxWidth()
            ) {

                Text("Open Donor Map")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {

                    navController.navigate(
                        NavRoutes.BLOOD_REQUEST
                    )
                },

                modifier =
                    Modifier.fillMaxWidth()
            ) {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ರಕ್ತ ವಿನಂತಿ"

                        "Hindi" ->
                            "रक्त अनुरोध"

                        else ->
                            "Blood Request"
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {

                    navController.navigate(
                        NavRoutes.AI_ASSISTANT
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಎಐ ರಕ್ತ ಸಹಾಯಕ"

                        "Hindi" ->
                            "एआई ब्लड असिस्टENT"

                        else ->
                            "AI Blood Assistant"
                    }
                )
            }
        }
    }
}