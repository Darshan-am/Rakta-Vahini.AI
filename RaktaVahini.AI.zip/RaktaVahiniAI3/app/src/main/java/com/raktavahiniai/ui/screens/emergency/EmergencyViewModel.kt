package com.raktavahiniai.ui.screens.emergency

class EmergencyViewModel {
}