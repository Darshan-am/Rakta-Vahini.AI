package com.raktavahiniai.data.remote.repository

class EmergencyRepositoryImpl {
}