package com.raktavahiniai.domain.usecase

class DonationEligibilityUseCase {
}