package com.raktavahiniai.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

import com.raktavahiniai.ui.screens.ai.AiAssistantScreen
import com.raktavahiniai.ui.screens.donor.DonorScreen
import com.raktavahiniai.ui.screens.emergency.EmergencyScreen
import com.raktavahiniai.ui.screens.history.HistoryScreen
import com.raktavahiniai.ui.screens.home.HomeScreen
import com.raktavahiniai.ui.screens.login.LoginScreen
import com.raktavahiniai.ui.screens.maps.DonorMapScreen
import com.raktavahiniai.ui.screens.profile.ProfileScreen
import com.raktavahiniai.ui.screens.ranking.RankingScreen
import com.raktavahiniai.ui.screens.register.RegisterScreen
import com.raktavahiniai.ui.screens.settings.SettingsScreen
import com.raktavahiniai.ui.screens.splash.SplashScreen
import com.raktavahiniai.ui.theme.ThemeViewModel
import com.raktavahiniai.ui.screens.emergencyfeed.EmergencyFeedScreen
import com.raktavahiniai.ui.screens.emergencyhistory.EmergencyHistoryScreen
import com.raktavahiniai.ui.screens.sos.SosScreen
import com.raktavahiniai.ui.screens.request.BloodRequestScreen
@Composable
fun AppNavigation(
    themeViewModel: ThemeViewModel
) {

    val navController =
        rememberNavController()

    NavHost(
        navController = navController,

        startDestination =
            NavRoutes.SPLASH
    ) {

        composable(
            NavRoutes.SPLASH
        ) {

            SplashScreen(navController)
        }

        composable(
            NavRoutes.LOGIN
        ) {

            LoginScreen(navController)
        }

        composable(
            NavRoutes.REGISTER
        ) {

            RegisterScreen(navController)
        }

        composable(
            NavRoutes.HOME
        ) {

            HomeScreen(navController)
        }

        composable(
            NavRoutes.HISTORY
        ) {

            HistoryScreen()
        }

        composable(
            NavRoutes.PROFILE
        ) {

            ProfileScreen(
                navController,
                themeViewModel
            )
        }

        composable(
            NavRoutes.SETTINGS
        ) {

            SettingsScreen()
        }

        composable(
            NavRoutes.DONOR
        ) {

            DonorScreen()
        }

        composable(
            NavRoutes.EMERGENCY
        ) {

            EmergencyScreen()
        }

        composable(
            NavRoutes.EMERGENCY_HISTORY
        ) {

            EmergencyHistoryScreen()
        }

        composable(
            NavRoutes.SOS
        ) {

            SosScreen()
        }

        composable(
            NavRoutes.EMERGENCY_FEED
        ) {

            EmergencyFeedScreen()
        }

        composable(
            NavRoutes.DONOR_MAP
        ) {

            DonorMapScreen()
        }

        composable(
            NavRoutes.AI_ASSISTANT
        ) {

            AiAssistantScreen()
        }

        composable(
            NavRoutes.RANKING
        ) {

            RankingScreen()
        }

        composable(
            NavRoutes.BLOOD_REQUEST
        ) {

            BloodRequestScreen()
        }
    }
}