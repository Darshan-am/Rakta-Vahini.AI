package com.raktavahiniai.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raktavahiniai.ui.theme.BloodRed

@Composable
fun DonorCard(
    donorName: String,
    bloodGroup: String,
    district: String,
    phone: String,
    available: Boolean,
    onAvailabilityChanged: (Boolean) -> Unit
) {

    val context = LocalContext.current

    var isAvailable by remember {
        mutableStateOf(available)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        )
    ) {

        Column(
            modifier = Modifier.padding(20.dp)
        ) {

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(BloodRed),
                    contentAlignment = Alignment.Center
                ) {

                    Text(
                        text = bloodGroup,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = donorName,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = district,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = phone,
                        color = Color.DarkGray
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isAvailable)
                                Color(0xFF4CAF50)
                            else
                                Color.Red
                        )
                        .padding(
                            horizontal = 12.dp,
                            vertical = 6.dp
                        )
                ) {

                    Text(
                        text =
                            if (isAvailable)
                                "Available"
                            else
                                "Busy",
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement =
                    Arrangement.SpaceBetween,
                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                Text(
                    text =
                        if (isAvailable)
                            "Available for Donation"
                        else
                            "Currently Busy"
                )

                Switch(
                    checked = isAvailable,
                    onCheckedChange = {

                        isAvailable = it

                        onAvailabilityChanged(it)
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {

                    val intent = Intent(
                        Intent.ACTION_DIAL
                    )

                    intent.data =
                        Uri.parse("tel:$phone")

                    context.startActivity(intent)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BloodRed
                )
            ) {

                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = null
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text("Call Donor")
            }
        }
    }
}