package com.raktavahiniai.domain.repository

class AuthRepository {
}