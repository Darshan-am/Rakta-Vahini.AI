package com.raktavahiniai.domain.usecase

class LoginUseCase {
}