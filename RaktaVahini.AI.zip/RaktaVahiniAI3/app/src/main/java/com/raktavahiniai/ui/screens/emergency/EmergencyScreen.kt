package com.raktavahiniai.ui.screens.emergency

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raktavahiniai.utils.LanguageManager

@Composable
fun EmergencyScreen() {

    val selectedLanguage =
        LanguageManager.selectedLanguage

    var patientName by remember {
        mutableStateOf("")
    }

    var bloodGroup by remember {
        mutableStateOf("")
    }

    var hospitalName by remember {
        mutableStateOf("")
    }

    var message by remember {
        mutableStateOf("")
    }

    var showDialog by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {

        Text(
            text =

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "🚨 ತುರ್ತು ರಕ್ತ ವಿನಂತಿ"

                    "Hindi" ->
                        "🚨 आपातकालीन रक्त अनुरोध"

                    else ->
                        "🚨 Emergency Blood Request"
                },

            style =
                MaterialTheme
                    .typography
                    .headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = patientName,

            onValueChange = {
                patientName = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ರೋಗಿಯ ಹೆಸರು"

                        "Hindi" ->
                            "मरीज का नाम"

                        else ->
                            "Patient Name"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = bloodGroup,

            onValueChange = {
                bloodGroup = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ರಕ್ತ ಗುಂಪು"

                        "Hindi" ->
                            "ब्लड ग्रुप"

                        else ->
                            "Blood Group"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = hospitalName,

            onValueChange = {
                hospitalName = it
            },

            modifier = Modifier.fillMaxWidth(),

            label = {

                Text(

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ಆಸ್ಪತ್ರೆಯ ಹೆಸರು"

                        "Hindi" ->
                            "अस्पताल का नाम"

                        else ->
                            "Hospital Name"
                    }
                )
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {

                message =

                    when (
                        selectedLanguage.value
                    ) {

                        "Kannada" ->
                            "ತುರ್ತು ವಿನಂತಿ ಯಶಸ್ವಿಯಾಗಿ ಕಳುಹಿಸಲಾಗಿದೆ."

                        "Hindi" ->
                            "आपातकालीन अनुरोध सफलतापूर्वक भेजा गया।"

                        else ->
                            "Emergency request sent successfully."
                    }

                showDialog = true
            },

            modifier =
                Modifier.fillMaxWidth()
        ) {

            Text(

                when (
                    selectedLanguage.value
                ) {

                    "Kannada" ->
                        "ವಿನಂತಿ ಕಳುಹಿಸಿ"

                    "Hindi" ->
                        "अनुरोध भेजें"

                    else ->
                        "Send Request"
                }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (message.isNotEmpty()) {

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = message,

                    modifier = Modifier
                        .padding(20.dp)
                )
            }
        }

        if (showDialog) {

            AlertDialog(

                onDismissRequest = {
                    showDialog = false
                },

                confirmButton = {

                    Button(
                        onClick = {
                            showDialog = false
                        }
                    ) {

                        Text("OK")
                    }
                },

                title = {

                    Text(

                        when (
                            selectedLanguage.value
                        ) {

                            "Kannada" ->
                                "ಯಶಸ್ಸು"

                            "Hindi" ->
                                "सफल"

                            else ->
                                "Success"
                        }
                    )
                },

                text = {

                    Text(message)
                }
            )
        }
    }
}