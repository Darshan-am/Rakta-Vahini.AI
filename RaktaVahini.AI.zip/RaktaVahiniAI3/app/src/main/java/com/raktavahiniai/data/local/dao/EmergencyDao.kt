package com.raktavahiniai.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.raktavahiniai.data.local.entities.EmergencyEntity

@Dao
interface EmergencyDao {

    @Insert
    suspend fun insertEmergencyRequest(
        emergency: EmergencyEntity
    )

    @Query("SELECT * FROM emergency_requests")
    suspend fun getAllEmergencyRequests():
            List<EmergencyEntity>
}