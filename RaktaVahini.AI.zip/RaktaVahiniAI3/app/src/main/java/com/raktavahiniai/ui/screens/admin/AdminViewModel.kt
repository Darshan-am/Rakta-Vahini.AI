package com.raktavahiniai.ui.screens.admin

class AdminViewModel {
}