package com.raktavahiniai.domain.model

class Donation {
}