package com.raktavahiniai.domain.usecase

class RegisterUseCase {
}