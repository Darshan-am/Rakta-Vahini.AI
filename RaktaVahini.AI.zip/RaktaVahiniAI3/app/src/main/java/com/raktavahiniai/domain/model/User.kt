package com.raktavahiniai.domain.model

class User {
}