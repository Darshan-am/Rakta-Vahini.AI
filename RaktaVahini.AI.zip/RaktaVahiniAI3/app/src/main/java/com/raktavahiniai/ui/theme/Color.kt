package com.raktavahiniai.ui.theme

import androidx.compose.ui.graphics.Color

val BloodRed = Color(0xFFC62828)
val DarkRed = Color(0xFF8E0000)
val White = Color(0xFFFFFFFF)