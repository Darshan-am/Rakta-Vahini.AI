package com.raktavahiniai.ui.screens.login

class LoginState {
}