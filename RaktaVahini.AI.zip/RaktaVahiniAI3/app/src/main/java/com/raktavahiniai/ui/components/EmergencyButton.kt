package com.raktavahiniai.ui.components

class EmergencyButton {
}