package com.raktavahiniai.ui.screens.receiver

class ReceiverViewModel {
}