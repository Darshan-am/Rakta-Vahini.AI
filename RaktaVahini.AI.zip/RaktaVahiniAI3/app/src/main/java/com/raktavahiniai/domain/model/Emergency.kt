package com.raktavahiniai.domain.model

class Emergency {
}