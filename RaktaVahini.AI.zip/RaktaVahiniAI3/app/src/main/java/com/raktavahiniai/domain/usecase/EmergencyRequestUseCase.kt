package com.raktavahiniai.domain.usecase

class EmergencyRequestUseCase {
}