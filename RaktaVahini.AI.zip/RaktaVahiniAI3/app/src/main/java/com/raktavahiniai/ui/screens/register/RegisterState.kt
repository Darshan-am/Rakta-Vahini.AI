package com.raktavahiniai.ui.screens.register

class RegisterState {
}